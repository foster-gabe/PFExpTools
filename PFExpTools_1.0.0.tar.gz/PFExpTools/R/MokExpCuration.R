library(PFExpTools)

##########################################################################
#
# Script: Mok Expression Curation
# Author: Gabe Foster
# Date: 3/24/2020
# Purpose: This script obtains the Mok 2015 expression data and expression
# metadata and curates it
#
##########################################################################


Mokdata <- fullCurate("GSE59097")

Mokexp <- Mokdata[[1]]

Mokexpmeta <- Mokdata[[2]]

write.csv(Mokexp, "Mok_curated_exp.csv")

write.csv(Mokexpmeta, "Mok_meta_exp.csv")

